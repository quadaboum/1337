"""Add InviteCode table

Revision ID: a7c86b6622bb
Revises: 
Create Date: 2025-05-16 11:01:46.249546

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a7c86b6622bb'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'invite_code',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('code', sa.String(length=16), nullable=False),
        sa.Column('created_by', sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(['created_by'], ['user.id']),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('code')
    )

def downgrade():
    op.drop_table('invite_code')
    
def downgrade():
    op.drop_table('invitation_codesS')
    
